CREATE DATABASE warehouseDB;
USE warehouseDB;

-- Products table
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100),
    product_type VARCHAR(50),
    quantity INT,
    price DECIMAL(10,2),
    storage_requirements VARCHAR(255)
);

-- Suppliers table
CREATE TABLE suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100),
    contact_name VARCHAR(100),
    contact_number VARCHAR(15),
    address VARCHAR(255)
);

-- StockRequests table
CREATE TABLE stock_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    supplier_id INT,
    requested_quantity INT,
    request_date DATETIME,
    status VARCHAR(50),
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);

-- ProductHistory table
CREATE TABLE product_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    change_type VARCHAR(50),
    quantity_change INT,
    change_date DATETIME,
    notes VARCHAR(255),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- InventoryLogs table
CREATE TABLE inventory_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    action VARCHAR(50),
    quantity INT,
    action_date DATETIME,
    performed_by VARCHAR(100),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

SELECT * FROM product_history WHERE product_id = 2;


select * from products;
select * from suppliers;
select * from stock_requests;
select * from product_history;
select * from Inventory_logs;