package controller;

import service.InventoryServiceImpl;
import java.util.Scanner;

public class WarehouseController {
    public static void main(String[] args) {
        InventoryServiceImpl inventoryService = new InventoryServiceImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Warehouse Management System ---");
            System.out.println("1. Add Product");
            System.out.println("2. Update Stock");
            System.out.println("3. Manage Suppliers");
            System.out.println("4. Generate Stock Report");
            System.out.println("5. Create Stock Request");
            System.out.println("6. View Product History");
            System.out.println("7. Log Inventory Action");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    inventoryService.addProduct();
                    break;
                case 2:
                    inventoryService.updateStock();
                    break;
                case 3:
                    inventoryService.manageSuppliers();
                    break;
                case 4:
                    inventoryService.generateStockReport();
                    break;
                case 5:
                    inventoryService.createStockRequest();
                    break;
                case 6:
                    System.out.println("Enter product ID to view history:");
                    int productId = scanner.nextInt();
                    inventoryService.viewProductHistory(productId);
                    break;
                case 7:
                    System.out.println("Enter product ID:");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Enter action type (e.g., 'Add', 'Remove'):");
                    String action = scanner.nextLine();
                    System.out.println("Enter quantity affected:");
                    int qty = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Enter your name:");
                    String performedBy = scanner.nextLine();
                    inventoryService.logInventoryAction(id, action, qty, performedBy);
                    break;
                case 8:
                    System.out.println("Exiting... Thank you for using the Warehouse Management System!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Please select a valid option.");
            }
        }
    }
}
