package service;

import model.DBConnection;
import model.product;
import model.StockRequest;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.Scanner;

public class InventoryServiceImpl implements InventoryService {
    private Scanner sc = new Scanner(System.in);

    @Override
    public void addProduct() {
        try (Connection conn = DBConnection.connect()) {
            // Step 1: Add the product to the 'products' table
            System.out.println("Enter product name:");
            String productName = sc.nextLine();
            System.out.println("Enter product type:");
            String productType = sc.nextLine();
            System.out.println("Enter quantity:");
            int quantity = sc.nextInt();
            System.out.println("Enter price:");
            double price = sc.nextDouble();
            sc.nextLine(); // Consume the newline character
            System.out.println("Enter storage requirements:");
            String storageRequirements = sc.nextLine();

            String query = "INSERT INTO products (product_name, product_type, quantity, price, storage_requirements) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, productName);
            pst.setString(2, productType);
            pst.setInt(3, quantity);
            pst.setDouble(4, price);
            pst.setString(5, storageRequirements);
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                // Step 2: Retrieve the generated product_id after inserting the product
                ResultSet rs = pst.getGeneratedKeys();
                if (rs.next()) {
                    int productId = rs.getInt(1);  // Get the generated product ID

                    // Step 3: Log the product addition in the 'product_history' table
                    String historyQuery = "INSERT INTO product_history (product_id, change_type, quantity_change, change_date, notes) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement historyPst = conn.prepareStatement(historyQuery);
                    historyPst.setInt(1, productId); // Use the generated productId
                    historyPst.setString(2, "Product Added");
                    historyPst.setInt(3, quantity);  // Assuming the quantity added is the change
                    historyPst.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));  // Current timestamp
                    historyPst.setString(5, "Initial stock added during product creation");
                    historyPst.executeUpdate();

                    System.out.println("Product added and history updated successfully!");
                }
            } else {
                System.out.println("Failed to add product.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }


    @Override
    public void updateStock() {
        try (Connection conn = DBConnection.connect()) {
            System.out.println("Enter product ID to update stock:");
            int productId = sc.nextInt();
            System.out.println("Enter new quantity:");
            int quantity = sc.nextInt();

            String query = "UPDATE products SET quantity = ? WHERE product_id = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, quantity);
            pst.setInt(2, productId);
            pst.executeUpdate();

            System.out.println("Stock updated successfully!");
        } catch (SQLException e) {
            System.out.println("Error updating stock: " + e.getMessage());
        }
    }

    @Override
    public void manageSuppliers() {
        System.out.println("\n--- Manage Suppliers ---");
        System.out.println("1. Add Supplier");
        System.out.println("2. View All Suppliers");
        System.out.print("Enter your choice: ");
        int choice = sc.nextInt();
        sc.nextLine();

        switch (choice) {
            case 1:
                addSupplier();
                break;
            case 2:
                viewSuppliers();
                break;
            default:
                System.out.println("Invalid choice! Please select a valid option.");
        }
    }

    private void addSupplier() {
        try (Connection conn = DBConnection.connect()) {
            System.out.println("Enter supplier name:");
            String supplierName = sc.nextLine();
            System.out.println("Enter contact name:");
            String contactName = sc.nextLine();
            System.out.println("Enter contact number:");
            String contactNumber = sc.nextLine();
            System.out.println("Enter address:");
            String address = sc.nextLine();

            String query = "INSERT INTO suppliers (supplier_name, contact_name, contact_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, supplierName);
            pst.setString(2, contactName);
            pst.setString(3, contactNumber);
            pst.setString(4, address);
            pst.executeUpdate();

            System.out.println("Supplier added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding supplier: " + e.getMessage());
        }
    }

    private void viewSuppliers() {
        try (Connection conn = DBConnection.connect(); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT * FROM suppliers");
            System.out.println("\n--- Suppliers List ---");
            while (rs.next()) {
                System.out.println("Supplier ID: " + rs.getInt("supplier_id") + ", Name: " + rs.getString("supplier_name") + 
                                   ", Contact: " + rs.getString("contact_name") + ", Phone: " + rs.getString("contact_number") +
                                   ", Address: " + rs.getString("address"));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving suppliers: " + e.getMessage());
        }
    }

    @Override
    public void generateStockReport() {
        try (Connection conn = DBConnection.connect(); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT * FROM products");
            System.out.println("\n--- Stock Report ---");
            while (rs.next()) {
                System.out.println("Product ID: " + rs.getInt("product_id") +
                                   ", Name: " + rs.getString("product_name") +
                                   ", Type: " + rs.getString("product_type") +
                                   ", Quantity: " + rs.getInt("quantity") +
                                   ", Price: $" + rs.getDouble("price"));
            }
        } catch (SQLException e) {
            System.out.println("Error generating stock report: " + e.getMessage());
        }
    }

    @Override
    public void createStockRequest() {
        try (Connection conn = DBConnection.connect()) {
            System.out.println("Enter product ID for stock request:");
            int productId = sc.nextInt();
            System.out.println("Enter supplier ID:");
            int supplierId = sc.nextInt();
            System.out.println("Enter requested quantity:");
            int quantity = sc.nextInt();
            sc.nextLine();

            String query = "INSERT INTO stock_requests (product_id, supplier_id, requested_quantity, request_date, status) VALUES (?, ?, ?, ?, 'Pending')";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, productId);
            pst.setInt(2, supplierId);
            pst.setInt(3, quantity);
            pst.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
            pst.executeUpdate();

            System.out.println("Stock request created successfully!");
            logInventoryAction(productId, "Stock Request", quantity, "System");

        } catch (SQLException e) {
            System.out.println("Error creating stock request: " + e.getMessage());
        }
    }

    @Override
    public void viewProductHistory(int productId) {
        try (Connection conn = DBConnection.connect()) {
            // Check if the product_id exists in the product_history table
            String checkQuery = "SELECT COUNT(*) FROM product_history WHERE product_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, productId);
            ResultSet checkRs = checkStmt.executeQuery();
            if (checkRs.next() && checkRs.getInt(1) == 0) {
                System.out.println("No history found for Product ID: " + productId);
                return;
            }

            // Query to fetch product history
            String query = "SELECT * FROM product_history WHERE product_id = ?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, productId);
            ResultSet rs = pst.executeQuery();

            // Print the results
            System.out.println("\n--- Product History for Product ID: " + productId + " ---");
            while (rs.next()) {
                System.out.println("History ID: " + rs.getInt("history_id") +
                                   ", Change Type: " + rs.getString("change_type") +
                                   ", Quantity Change: " + rs.getInt("quantity_change") +
                                   ", Date: " + rs.getTimestamp("change_date") +
                                   ", Notes: " + rs.getString("notes"));
            }
        } catch (SQLException e) {
            System.out.println("Error viewing product history: " + e.getMessage());
        }
    }


    @Override
    public void logInventoryAction(int productId, String action, int quantity, String performedBy) {
        try (Connection conn = DBConnection.connect()) {
            String query = "INSERT INTO inventory_logs (product_id, action, quantity, action_date, performed_by) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, productId);
            pst.setString(2, action);
            pst.setInt(3, quantity);
            pst.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
            pst.setString(5, performedBy);
            pst.executeUpdate();

            System.out.println("Inventory action logged successfully!");
        } catch (SQLException e) {
            System.out.println("Error logging inventory action: " + e.getMessage());
        }
    }
}
