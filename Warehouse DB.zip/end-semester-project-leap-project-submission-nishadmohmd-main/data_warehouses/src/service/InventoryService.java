package service;

public interface InventoryService {
    void addProduct();
    void updateStock();
    void manageSuppliers();
    void generateStockReport();
    void createStockRequest();
    void viewProductHistory(int productId);
    void logInventoryAction(int productId, String action, int quantity, String performedBy);
}
