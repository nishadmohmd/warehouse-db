/**
 * 
 */
/**
 * 
 */
module data_warehouses {
	requires java.sql;
}