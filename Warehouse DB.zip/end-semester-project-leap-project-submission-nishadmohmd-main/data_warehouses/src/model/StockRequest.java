package model;

import java.time.LocalDateTime;

public class StockRequest {
    private int requestId;
    private int productId;
    private int supplierId;
    private int requestedQuantity;
    private LocalDateTime requestDate;
    private String status;

    public StockRequest(int productId, int supplierId, int requestedQuantity, String status) {
        this.productId = productId;
        this.supplierId = supplierId;
        this.requestedQuantity = requestedQuantity;
        this.requestDate = LocalDateTime.now();
        this.status = status;
    }

    public int getRequestId() { return requestId; }
    public void setRequestId(int requestId) { this.requestId = requestId; }
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
    public int getRequestedQuantity() { return requestedQuantity; }
    public void setRequestedQuantity(int requestedQuantity) { this.requestedQuantity = requestedQuantity; }
    public LocalDateTime getRequestDate() { return requestDate; }
    public void setRequestDate(LocalDateTime requestDate) { this.requestDate = requestDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
