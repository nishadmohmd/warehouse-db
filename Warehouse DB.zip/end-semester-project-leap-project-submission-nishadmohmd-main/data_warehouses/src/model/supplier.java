package model;

public class supplier {
    private int supplierId;
    private String supplierName;
    private String contactName;
    private String contactNumber;
    private String address;

    public supplier(String supplierName, String contactName, String contactNumber, String address) {
        this.supplierName = supplierName;
        this.contactName = contactName;
        this.contactNumber = contactNumber;
        this.address = address;
    }

    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
    public String getSupplierName() { return supplierName; }
    public void setSupplierName(String supplierName) { this.supplierName = supplierName; }
    public String getContactName() { return contactName; }
    public void setContactName(String contactName) { this.contactName = contactName; }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}
